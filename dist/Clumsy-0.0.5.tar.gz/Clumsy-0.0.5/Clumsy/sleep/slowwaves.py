"""Script for detection of slow-waves using amplitude based detection, fast frequency based detection, duration based
detection, and power ratio based detections"""